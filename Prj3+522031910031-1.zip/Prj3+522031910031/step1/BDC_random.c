#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <time.h>

#include "../include/tcp_utils.h"
#define BLOCKSIZE 256
#define BUFFER_SIZE 4096
void generate_random_data(char *data, int length) {
    static const char charset[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    for (int i = 0; i < length - 1; i++) {
        int key = rand() % (int)(sizeof(charset) - 1);
        data[i] = charset[key];
    }
    data[length - 1] = '\0';
}


int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <Port>", argv[0]);
        exit(EXIT_FAILURE);
    }
    int port = atoi(argv[1]);
    int cylinders, sectors;

    tcp_client client = client_init("localhost", port);
    static char buf[BUFFER_SIZE];
    printf("Request 0: I\n");
    strcpy(buf, "I");
    client_send(client, buf, strlen(buf) + 1);
    int n = client_recv(client, buf, sizeof(buf));
    buf[n] = 0;
    printf("%s\n", buf);
    sscanf(buf, "%d %d", &cylinders, &sectors);
    printf("Totally %d cylinders, %d sectors per cylinder.\n", cylinders, sectors);
    printf("Please input the number of R/W requests: ");
    
    int nn;
    scanf("%d", &nn);

    srand(time(NULL)); // Seed the random number generator
    for (int i = 0; i < nn; i++) 
    {
        int is_write = rand() % 2;
        int cyl = rand() % cylinders;
        int sec = rand() % sectors;
        if (is_write) {
            char data[BLOCKSIZE];
            generate_random_data(data, BLOCKSIZE);
            printf("Request %d: W %d %d %lu %s\n", i + 1, cyl, sec, strlen(data) + 1, data);
            snprintf(buf, sizeof(buf), "W %d %d %lu %s", cyl, sec, strlen(data) + 1, data);
            client_send(client, buf, strlen(buf) + 1);
            int n = client_recv(client, buf, sizeof(buf));
            buf[n] = 0;
            //printf("%s\n", buf);
            if (strcmp(buf, "Bye!") == 0) break;
        } else {
            printf("Request %d: R %d %d\n", i + 1, cyl, sec);
            snprintf(buf, sizeof(buf), "R %d %d", cyl, sec);
            client_send(client, buf, strlen(buf) + 1);
            int n = client_recv(client, buf, sizeof(buf));
            buf[n] = 0;
            printf("%s\n", buf);
            if (strcmp(buf, "Bye!") == 0) break;
        }
    }
    printf("Request %d: E\n",nn+1);
    strcpy(buf, "E");
    client_send(client, buf, strlen(buf) + 1);
    n = client_recv(client, buf, sizeof(buf));
    buf[n] = 0;
    printf("%s\n", buf);


    client_destroy(client);
}
