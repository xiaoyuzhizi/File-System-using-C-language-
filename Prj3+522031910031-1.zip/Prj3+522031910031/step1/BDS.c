#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

#include "../include/tcp_utils.h"

// Block size in bytes
#define BLOCKSIZE 256
int ncyl, nsec, ttd;
char* diskfile;
int cur_cyl = 0; // 当前磁头所在柱面

// return a negative value to exit
int cmd_i(tcp_buffer *write_buf, char *args, int len) {
    static char buf[64];
    sprintf(buf, "%d %d", ncyl, nsec);

    // send to buffer, including the null terminator
    send_to_buffer(write_buf, buf, strlen(buf) + 1);
    return 0;
}

int cmd_r(tcp_buffer *write_buf, char *args, int len) {
    int cyl, sec;
    if (sscanf(args, "%d %d", &cyl, &sec) != 2 || cyl >= ncyl || sec >= nsec) {
        send_to_buffer(write_buf, "Error: Invalid read parameters.", 32);
        return 0;
    }
    int tsleep = abs(cur_cyl - cyl) * ttd;
    usleep(tsleep * 1000);
    cur_cyl = cyl; // 更新当前磁头位置
    char* block = diskfile + (cyl * nsec + sec) * BLOCKSIZE;
    send_to_buffer(write_buf, block, BLOCKSIZE);
    return 0;

    // send_to_buffer(write_buf, args, len);
    // return 0;
}

int cmd_w(tcp_buffer *write_buf, char *args, int len) {
    int cyl, sec, data_len;
    // 解析参数c, s, l
    if (sscanf(args, "%d %d %d", &cyl, &sec, &data_len) != 3 || cyl >= ncyl || sec >= nsec || data_len > BLOCKSIZE) {
        send_to_buffer(write_buf, "Error: Invalid write parameters.", 33);
        return 0;
    }
    
    // 确保 data_len 不超过 BLOCKSIZE
    if (data_len < 0 || data_len > BLOCKSIZE) {
        send_to_buffer(write_buf, "Error: Invalid data length.", 28);
        return 0;
    }

    // 计算磁头移动时间并模拟延迟
    int tsleep = abs(cur_cyl - cyl) * ttd;
    usleep(tsleep * 1000);
    cur_cyl = cyl; // 更新当前磁头位置

    // 计算数据块的起始位置
    char *block = diskfile + (cyl * nsec + sec) * BLOCKSIZE;
    // 清空目标扇区
    memset(block, 0, BLOCKSIZE);
    // 计算写入数据在 args 中的起始位置
    char *data_start = strchr(args, ' ') + 1; // 跳过第一个空格后的字符
    data_start = strchr(data_start, ' ') + 1; // 跳过第二个空格后的字符
    data_start = strchr(data_start, ' ') + 1; // 跳过第三个空格后的字符

    // 检查 data_start 是否指向有效的地址
    if (data_start - args > len) {
        send_to_buffer(write_buf, "Error: Malformed command.", 26);
        return 0;
    }

    // 进行数据写入
    memcpy(block, data_start, data_len);
    //send_to_buffer(write_buf, "Write successful", 17);
    send_to_buffer(write_buf, data_start, data_len);

    return 0;



    // send_to_buffer(write_buf, "Yes", 4);
    // return 0;
}

int cmd_e(tcp_buffer *write_buf, char *args, int len) {
    send_to_buffer(write_buf, "Bye!", 5);
    return -1;
}

static struct {
    const char *name;
    int (*handler)(tcp_buffer *write_buf, char *, int);
} cmd_table[] = {
    {"I", cmd_i},
    {"R", cmd_r},
    {"W", cmd_w},
    {"E", cmd_e},
};

#define NCMD (sizeof(cmd_table) / sizeof(cmd_table[0]))

void add_client(int id) {
    // some code that are executed when a new client is connected
    // you don't need this in step1
}

int handle_client(int id, tcp_buffer *write_buf, char *msg, int len) {
    char *p = strtok(msg, " \r\n");
    int ret = 1;
    for (int i = 0; i < NCMD; i++)
        if (strcmp(p, cmd_table[i].name) == 0) {
            ret = cmd_table[i].handler(write_buf, p + strlen(p) + 1, len - strlen(p) - 1);
            break;
        }
    if (ret == 1) {
        static char unk[] = "Unknown command";
        send_to_buffer(write_buf, unk, sizeof(unk));
    }
    if (ret < 0) {
        return -1;
    }
}

void clear_client(int id) {
    // some code that are executed when a client is disconnected
    // you don't need this in step2
}

int main(int argc, char *argv[]) {
    if (argc < 5) {
        fprintf(stderr,
                "Usage: %s <disk file name> <cylinders> <sector per cylinder> "
                "<track-to-track delay> <port>\n",
                argv[0]);
        exit(EXIT_FAILURE);
    }
    // args
    char *diskfname = argv[1];
    ncyl = atoi(argv[2]);
    nsec = atoi(argv[3]);
    ttd = atoi(argv[4]);  // ms
    int port = atoi(argv[5]);

    // open file
    int fd = open (diskfname, O_RDWR | O_CREAT, 0);
    if (fd < 0) {
        printf("Error: Could not open file '%s'.\n", diskfname);
        exit(-1);
    }

    // stretch the file
    long FILESIZE = BLOCKSIZE * ncyl * nsec;
    int result = lseek (fd, FILESIZE-1, SEEK_SET);
    if (result == -1) {
        perror ("Error calling lseek() to 'stretch' the file");
        close (fd);
        exit(-1); 
    }
    result = write (fd, "", 1);
    if (result != 1) {
        perror("Error writing last byte of the file");
        close(fd);
        exit(-1);
    }
    // mmap
    diskfile= (char *)mmap(NULL, FILESIZE,PROT_READ | PROT_WRITE,MAP_SHARED, fd, 0);
    if (diskfile== MAP_FAILED)
    {
        close(fd);
        printf("Error: Could not map file.\n");
        exit(-1);
    }
    // command
    tcp_server server = server_init(port, 1, add_client, handle_client, clear_client);
    server_loop(server);
}
