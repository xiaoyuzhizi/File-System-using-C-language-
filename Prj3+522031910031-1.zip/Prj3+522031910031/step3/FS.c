#include <assert.h>
#include <err.h>
#include <fcntl.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <time.h>
#include <unistd.h>
#include <stdint.h>
#include "../include/tcp_utils.h"
#define MAX_FILENAME_LEN 200
#define FREE_BLOCKS_START 1000  
#define SECTOR_SIZE 256
#define NUM_DIRECT_POINTERS 10  // Number of direct block pointers in the inode
#define MAX_INODES 100
//#define NUM_BLOCKS 1000  // Number of blocks is greater than number of inodes
#define FILE_TYPE 1
#define DIR_TYPE 2
#define BUFFER_SIZE 4096
#define MAX_USERS 100
#define MAX_PASSWORD_LEN 50
int FREE_BLOCKS_SIZE ;
typedef struct {
    int is_used;
    int type;                      // 文件类型：文件或目录
    int parent_inode;          // inode of parent directory
    int direct_blocks[NUM_DIRECT_POINTERS];
    time_t last_modified;       // Last modification time
    int size;             // Name of the file or directory
    int owner_id;           // User ID of the owner
    int permissions;        // 0: private, 1: public
} inode;

// 编码函数
void inode_to_string(inode* node, char* buffer, int buffer_size) {
    int offset = snprintf(buffer, buffer_size, "%d,%d,%d", node->is_used, node->type, node->parent_inode);
    for (int i = 0; i < NUM_DIRECT_POINTERS; i++) {
        offset += snprintf(buffer + offset, buffer_size - offset, ",%d", node->direct_blocks[i]);
    }
    offset += snprintf(buffer + offset, buffer_size - offset, ",%ld,%d", node->last_modified, node->size);
}

// 解码函数
void string_to_inode(const char* str, inode* node) {
    sscanf(str, "%d,%d,%d", &node->is_used, &node->type, &node->parent_inode);
    const char* ptr = str;
    for (int i = 0; i < 3; i++) {
        while (*ptr != ',' && *ptr != '\0') {
            ptr++;
        }
        ptr++; // 跳过逗号
    }
    for (int i = 0; i < NUM_DIRECT_POINTERS; i++) {
        sscanf(ptr, "%d", &node->direct_blocks[i]);
        while (*ptr != ',' && *ptr != '\0') {
            ptr++;
        }
        if (*ptr == ',') {
            ptr++;
        }
    }
    sscanf(ptr, "%ld,%d", &node->last_modified, &node->size);
}
inode inodes[MAX_INODES];
inode *get_inode(int inode_index) {
    if (inode_index >= 0 && inode_index < MAX_INODES) {
        return &inodes[inode_index];
    }
    return NULL;
}
typedef struct {
    int is_used;  //1表示有用，0表示没用
    char username[MAX_FILENAME_LEN];
    char password[MAX_PASSWORD_LEN];
    int home_inode;
} user;
user users[MAX_USERS];
// 编码函数
void user_to_string(user* usr, char* buffer, int buffer_size) {
    snprintf(buffer, buffer_size, "%d,%s,%s,%d", usr->is_used, usr->username, usr->password, usr->home_inode);
}

// 解码函数
void string_to_user(const char* str, user* usr) {
    sscanf(str, "%d,%[^,],%[^,],%d", &usr->is_used, usr->username, usr->password, &usr->home_inode);
}

tcp_client client;
//int free_blocks[NUM_BLOCKS];
int current_directory_inode = 0;
int current_user_id = -1;  // -1 means no user is logged in

//int num_inodes = 0;
int ncyl=100, nsec=100,size=10000;
int *free_blocks;
typedef struct {
    char name[MAX_FILENAME_LEN];
    int inode_index;
} directory_entry;
//directory_entry root_directory[MAX_DIRECTORY_ENTRIES];
// 编码函数
void directory_entry_to_string(directory_entry* entry, char* buffer, int buffer_size) {
    snprintf(buffer, buffer_size, "%s,%d", entry->name, entry->inode_index);
}
// 解码函数
void string_to_directory_entry(const char* str, directory_entry* entry) {
    sscanf(str, "%[^,],%d", entry->name, &entry->inode_index);
}
void write_data_to_disk(const char* data, int block_number, int nsec) {
    int cyc_write = block_number / nsec;
    int sec_write = block_number % nsec;
    static char buf[BUFFER_SIZE];
    snprintf(buf, sizeof(buf), "W %d %d %lu %s", cyc_write, sec_write, strlen(data), data);
    client_send(client, buf, strlen(buf) + 1);
    int n = client_recv(client, buf, sizeof(buf));
    buf[n] = 0;
    printf("%s\n", buf);
}
// void write_data_to_disk2(const char* data, int block_number, int nsec) {
//     int cyc_write = block_number / nsec;
//     int sec_write = block_number % nsec;
//     static char buf[BUFFER_SIZE];
//     snprintf(buf, sizeof(buf), "W %d %d %lu %s", cyc_write, sec_write, 256, data);
//     client_send(client, buf, strlen(buf) + 1);
//     int n = client_recv(client, buf, sizeof(buf));
//     buf[n] = 0;
//     printf("%s\n", buf);
// }
void write_inode_to_disk(inode *node, int inode_index) {
    char data[SECTOR_SIZE];
    inode_to_string(node, data, SECTOR_SIZE);
    int block_number = ncyl*nsec-1-inode_index; // Assuming each inode is stored in its corresponding block number
    write_data_to_disk(data, block_number, nsec);
}

char current_path[MAX_FILENAME_LEN + 1] = "/";

// Initialize the file system
void initialize_inodes() {
    for (int i = 0; i < MAX_INODES; i++) {
        inodes[i].is_used = 0;
        for(int j=0;j<NUM_DIRECT_POINTERS;j++){
            inodes[i].direct_blocks[j] = -1;
            //inodes[i].use_block[j] = -1;
        }
    }
}

void initialize_free_blocks() {
    for (int i = 0; i < size; i++) {
        free_blocks[i] = 1;  // All blocks are initially free
    }
}
void initialize_users() {
    for (int i = 0; i < MAX_USERS; i++) {
        users[i].is_used = 0;
    }
}

// void initialize_root_directory() {
//     for (int i = 0; i < MAX_DIRECTORY_ENTRIES; i++) {
//         root_directory[i].is_used = 0;
//     }
// }
int allocate_block() {
    for (int i = 0; i < size; i++) {
        if (free_blocks[i]) {
            free_blocks[i] = 0;
            return i;
        }
    }
    return -1;
}
int allocate_inode() {
    for (int i = 0; i < MAX_INODES; i++) {
        if (!inodes[i].is_used) {
            inodes[i].is_used = 1;
            int block_number = ncyl*nsec-1-i;
            free_blocks[block_number] = 0;
            return i;
        }
    }
    return -1;
}
int allocate_user() {
    for (int i = 0; i < MAX_USERS; i++) {
        if (!users[i].is_used) {
            users[i].is_used = 1;
            return i;
        }
    }
    return -1;
}
void write_users_to_disk() {
    char buffer[BUFFER_SIZE];
    for (int i = 0; i < MAX_USERS; i++) {
        if (users[i].is_used) {
            user_to_string(&users[i], buffer, sizeof(buffer));
            int block_number = size - 1 - MAX_INODES - i; // Correct block number for user data
            write_data_to_disk(buffer, block_number, nsec);
        }
    }
}
void read_users_from_disk() {
    char buffer[BUFFER_SIZE];
    for (int i = 0; i < MAX_USERS; i++) {
        int block_number = size - 1 - MAX_INODES - i; // Correct block number for user data
        read_block(block_number, buffer, sizeof(buffer));
        if (strlen(buffer) > 0) {
            string_to_user(buffer, &users[i]);
        }
    }
}


void update_file_size(int inode_index, int size_change) {
    inode *node = get_inode(inode_index);
    if (!node) {
        printf("Error: Inode %d not found\n", inode_index);
        return;
    }

    // Update the size of the current inode
    node->size += size_change;
    node->last_modified = time(NULL);

    // Write the updated inode to disk
    write_inode_to_disk(node, inode_index);

    // If it's not the root directory, recursively update the parent inode
    if (inode_index != 0 && inode_index != node->parent_inode) {
        update_file_size(node->parent_inode, size_change);
    }
}



void format_file_system(tcp_buffer *write_buf, char *args, int len) {
    initialize_inodes();
    initialize_free_blocks();
    initialize_users();
    int root_inode_index = allocate_inode();
    inodes[root_inode_index].type = DIR_TYPE;
    inodes[root_inode_index].parent_inode = root_inode_index; // Root's parent is itself
    inodes[root_inode_index].last_modified = time(NULL);
    inodes[root_inode_index].size = 0;
    inodes[root_inode_index].owner_id = -1;
    inodes[root_inode_index].permissions = 1; // Public
    current_directory_inode = root_inode_index;
    write_inode_to_disk(&inodes[root_inode_index], root_inode_index);
    strcpy(current_path, "/");
    send_to_buffer(write_buf, "formatted", 10);
    return;

}
int authenticate_user(const char *username, const char *password) {
    for (int i = 0; i < MAX_USERS; i++) {
        if (users[i].is_used && strcmp(users[i].username, username) == 0 && strcmp(users[i].password, password) == 0) {
            return i;
        }
    }
    return -1;
}

// int add_directory_entry(const char *name, int inode_index) {
//     for (int i = 0; i < MAX_DIRECTORY_ENTRIES; i++) {
//         if (!root_directory[i].is_used) {
//             root_directory[i].is_used = 1;
//             strncpy(root_directory[i].name, name, MAX_FILENAME_LEN);
//             root_directory[i].inode_index = inode_index;
//             return 0;
//         }
//     }
//     return -1;
// }
// void send_to_buffer(tcp_buffer *write_buf, const char *m
// void mk(const char *filename) {
int add_directory_entry(const char *name, int cur_inode_index, int tar_inode_index)
{
    inode *cnode = get_inode(cur_inode_index);
    int block_number;
    for (int i = 0; i < NUM_DIRECT_POINTERS; i++) {
        if (cnode->direct_blocks[i] == -1) {
            block_number = allocate_block();
            cnode->direct_blocks[i] = block_number;
            break;
        }
    }
    directory_entry my_entry;
    my_entry.inode_index=tar_inode_index;
    strcpy(my_entry.name,name);

    char data[SECTOR_SIZE];

    // 编码
    directory_entry_to_string(&my_entry, data, sizeof(data));
    printf("data: %s\n",data);
    write_data_to_disk(data, block_number, nsec);
    
    return 0;
}

void mk(tcp_buffer *write_buf, char *args, int len) {
    char filename[MAX_FILENAME_LEN + 1];  // Allocate buffer for filename
    if (sscanf(args, "%200s", filename) != 1 || strlen(filename) > MAX_FILENAME_LEN) {
        send_to_buffer(write_buf, "Error: Invalid filename", 25);
        return;
    }

    int inode_index = allocate_inode();
    if (inode_index == -1) {
        send_to_buffer(write_buf, "No free inodes available", 25);
        return;
    }

    inode *node = get_inode(inode_index);
    if (!node) {
        send_to_buffer(write_buf, "Error retrieving inode", 23);
        return;
    }

    node->type = FILE_TYPE;
    node->size = 0;
    node->last_modified = time(NULL);
    node->parent_inode = current_directory_inode;
    node->owner_id = current_user_id; // Set the owner to the current user
    node->permissions = 1; // Default to private

    add_directory_entry(filename, current_directory_inode, inode_index);
    update_file_size(current_directory_inode, sizeof(directory_entry) + sizeof(inode));
    send_to_buffer(write_buf, "file created!", 14);
    return;
}

void mkdir(tcp_buffer *write_buf, char *args, int len) {
    char filename[MAX_FILENAME_LEN + 1];  // Allocate buffer for filename
    if (sscanf(args, "%200s", filename) != 1 || strlen(filename) > MAX_FILENAME_LEN) {
        send_to_buffer(write_buf, "Error: Invalid filename", 25);
        return;
    }

    int inode_index = allocate_inode();
    if (inode_index == -1) {
        send_to_buffer(write_buf, "No free inodes available", 25);
        return;
    }

    inode *node = get_inode(inode_index);
    if (!node) {
        send_to_buffer(write_buf, "Error retrieving inode", 23);
        return;
    }

    node->type = DIR_TYPE;
    node->size = 0;
    node->last_modified = time(NULL);
    node->parent_inode = current_directory_inode;
    node->owner_id = current_user_id; // Set the owner to the current user
    node->permissions = 1; // Default to private

    add_directory_entry(filename, current_directory_inode, inode_index);
    update_file_size(current_directory_inode, sizeof(directory_entry) + sizeof(inode));
    send_to_buffer(write_buf, "directory created!", 19);
    return;
}






void read_block(int block_number, char *data, int buffer_size) {
    snprintf(data, buffer_size, "R %d %d", block_number / nsec, block_number % nsec);
    client_send(client, data, strlen(data) + 1);
    int n = client_recv(client, data, buffer_size);
    data[n] = 0;
    return;
}

void ls(tcp_buffer *write_buf, char *args, int len) {
    inode *cnode = get_inode(current_directory_inode);
    if (!cnode) {
        send_to_buffer(write_buf, "Error retrieving current directory inode", 41);
        return;
    }
    char buffer[BUFFER_SIZE];
    int offset = snprintf(buffer, sizeof(buffer), "Current directory size: %d bytes, last modified: %s\n", cnode->size, ctime(&cnode->last_modified));
    for (int i = 0; i < NUM_DIRECT_POINTERS; i++) {
        if (cnode->direct_blocks[i] != -1) {
            char data[BUFFER_SIZE];
            int block_number = cnode->direct_blocks[i];
            read_block(block_number, data, sizeof(data));
            directory_entry entry;
            string_to_directory_entry(data, &entry);
            inode *entry_node = get_inode(entry.inode_index);
            if (entry_node->owner_id == current_user_id ||current_user_id==-1|| entry_node->permissions == 1) {
                offset += snprintf(buffer + offset, sizeof(buffer) - offset, "%s\t", entry.name);
            }
        }
    }
    send_to_buffer(write_buf, buffer, strlen(buffer) + 1);
}


directory_entry *get_directory_entry(const char *name) {
    inode *cnode = get_inode(current_directory_inode);
    if (!cnode) {
        return NULL;
    }
    for (int i = 0; i < NUM_DIRECT_POINTERS; i++) {
        if (cnode->direct_blocks[i] != -1) {
            char data[BUFFER_SIZE];
            int block_number = cnode->direct_blocks[i];
            read_block(block_number, data, sizeof(data));
            directory_entry entry;
            string_to_directory_entry(data, &entry);
            if (strcmp(entry.name, name) == 0) {
                directory_entry *found_entry = (directory_entry *)malloc(sizeof(directory_entry));
                if (found_entry != NULL) {
                    *found_entry = entry;
                }
                return found_entry;
            }
        }
    }
    return NULL;
}
void rm(tcp_buffer *write_buf, char *args, int len) {
    char filename[MAX_FILENAME_LEN + 1];  // Allocate buffer for filename
    if (sscanf(args, "%200s", filename) != 1 || strlen(filename) > MAX_FILENAME_LEN) {
        send_to_buffer(write_buf, "Error: Invalid ", 32);
        return;
    }
    directory_entry *entry = get_directory_entry(filename);
    if (entry == NULL) {
        send_to_buffer(write_buf, "File not found", 15);
        return;
    }
    inode *node = get_inode(entry->inode_index);
    if (!node) {
        send_to_buffer(write_buf, "Error retrieving inode", 23);
        free(entry);
        return;
    }
    // Free the blocks used by the file
    for (int i = 0; i < NUM_DIRECT_POINTERS; i++) {
        if (node->direct_blocks[i] != -1) {
            free_blocks[node->direct_blocks[i]] = 1;
            node->direct_blocks[i] = -1;
        }
    }
    // Free the inode
    node->is_used = 0;
    inodes[current_directory_inode].last_modified = time(NULL);
    // Remove the directory entry
    inode *cnode = get_inode(current_directory_inode);
    for (int i = 0; i < NUM_DIRECT_POINTERS; i++) {
        if (cnode->direct_blocks[i] != -1) {
            char data[BUFFER_SIZE];
            int block_number = cnode->direct_blocks[i];
            read_block(block_number, data, sizeof(data));
            directory_entry dir_entry;
            string_to_directory_entry(data, &dir_entry);
            if (dir_entry.inode_index == entry->inode_index) {
                cnode->direct_blocks[i] = -1;
                free_blocks[block_number] = 1;
                break;
            }
        }
    }
    update_file_size(current_directory_inode, -(sizeof(directory_entry) +sizeof(inode) +node->size));
    send_to_buffer(write_buf, "file deleted", 13);
    free(entry);
    return;
}



void update_current_path(const char *new_dir) {
    if (strcmp(new_dir, "..") == 0) {
        if (strcmp(current_path, "/") != 0) {
            char *last_slash = strrchr(current_path, '/');
            if (last_slash != NULL) {
                if (last_slash == current_path) {
                    *(last_slash + 1) = '\0';
                } else {
                    *last_slash = '\0';
                }
            }
        }
    } else if (strcmp(new_dir, ".") != 0) {
        if (strcmp(current_path, "/") != 0) {
            strcat(current_path, "/");
        }
        strcat(current_path, new_dir);
    }
}


void cd(tcp_buffer *write_buf, char *args, int len) {
    char path[MAX_FILENAME_LEN + 1];

    if (sscanf(args, "%200s", path) != 1 || strlen(path) > MAX_FILENAME_LEN) {
        send_to_buffer(write_buf, "Error: Invalid ", 32);
        return;
    }
    if (strcmp(path, "/") == 0) {
        current_directory_inode = 0;
        strcpy(current_path, "/");
        send_to_buffer(write_buf, "Changed to root directory", 27);
        return;
    }
    char *token;
    char temp_path[MAX_FILENAME_LEN + 1];
    strcpy(temp_path, path);
    token = strtok(temp_path, "/");
    int inode_index = current_directory_inode;
    while (token != NULL) {
        if (strcmp(token, ".") == 0) {
            token = strtok(NULL, "/");
            continue;
        }
        if (strcmp(token, "..") == 0) {
            inode *current_inode = get_inode(inode_index);
            if (current_inode == NULL) {
                send_to_buffer(write_buf, "Error retrieving current directory inode", 41);
                return;
            }
            inode_index = current_inode->parent_inode;
            token = strtok(NULL, "/");
            continue;
        }
        printf("1\n");
        directory_entry *entry = get_directory_entry(token);
        if (entry == NULL) {
            send_to_buffer(write_buf, "Directory not found", 20);
            return;
        }
        printf("2\n");
        printf("entry->inode_index: %d\n",entry->inode_index);
        inode *node = get_inode(entry->inode_index);
        if (node == NULL || node->type != DIR_TYPE) {
            send_to_buffer(write_buf, "Not a directory", 17);
            return;
        }
        printf("3\n");
        inode_index = entry->inode_index;
        token = strtok(NULL, "/");
    }
    current_directory_inode = inode_index;
    update_current_path(path);
    send_to_buffer(write_buf, "Directory changed", 18);
    return;
}

void rmdir_r(int inode_index,tcp_buffer *write_buf, char *args, int len)
{

    inode *node = get_inode(inode_index);
    if (!node || node->type != DIR_TYPE) {
        send_to_buffer(write_buf, "Not a directory", 17);
        
        return;
    }
    for (int i = 0; i < NUM_DIRECT_POINTERS; i++) {
        if (node->direct_blocks[i] != -1) {
            char data[BUFFER_SIZE];
            int block_number = node->direct_blocks[i];
            read_block(block_number, data, sizeof(data));
            directory_entry temp_entry;
            string_to_directory_entry(data, &temp_entry);

            if(inodes[temp_entry.inode_index].type==DIR_TYPE){
                rmdir_r(temp_entry.inode_index,write_buf,args,len);
            }
            else
            {
                if(inodes[temp_entry.inode_index].type==FILE_TYPE){
                    rm(write_buf,temp_entry.name,strlen(temp_entry.name));
                }
            }
            
        }
    }
    // Free the blocks used by the directory
    for (int i = 0; i < NUM_DIRECT_POINTERS; i++) {
        if (node->direct_blocks[i] != -1) {
            free_blocks[node->direct_blocks[i]] = 1;
            node->direct_blocks[i] = -1;
        }
    }
    // Free the inode

    node->is_used = 0;
    free_blocks[ncyl*nsec-1-inode_index] = 1;
    // Remove the directory entry
    
    return;
}


void cmdrmdir(tcp_buffer *write_buf, char *args, int len) {
    char dirname[MAX_FILENAME_LEN + 1];
    if (sscanf(args, "%200s", dirname) != 1 || strlen(dirname) > MAX_FILENAME_LEN) {
        send_to_buffer(write_buf, "Error: Invalid ", 32);
        return;
    }
    directory_entry *entry = get_directory_entry(dirname);
    if (entry == NULL) {
        send_to_buffer(write_buf, "Directory not found", 20);
        return;
    }
    inode *node = get_inode(entry->inode_index);
    if (!node || node->type != DIR_TYPE) {
        send_to_buffer(write_buf, "Not a directory", 17);
        free(entry);
        return;
    }
    int tmpsize=node->size;
    rmdir_r(entry->inode_index,write_buf,args,len);
    inode *cnode = get_inode(current_directory_inode);
    for (int i = 0; i < NUM_DIRECT_POINTERS; i++) {
        if (cnode->direct_blocks[i] != -1) {
            char data[BUFFER_SIZE];
            int block_number = cnode->direct_blocks[i];
            read_block(block_number, data, sizeof(data));
            directory_entry dir_entry;
            string_to_directory_entry(data, &dir_entry);
            if (dir_entry.inode_index == entry->inode_index) {
                cnode->direct_blocks[i] = -1;
                free_blocks[block_number] = 1;
                break;
            }
        }
    }
    inodes[current_directory_inode].last_modified = time(NULL);
    update_file_size(current_directory_inode, -(sizeof(directory_entry) + sizeof(inode) + node->size));
    send_to_buffer(write_buf, "directory deleted", 18);
    free(entry);
    return;
}
void write_to_file(tcp_buffer *write_buf, char *args, int len) {
    char filename[MAX_FILENAME_LEN + 1];
    int data_len;
    char data[BUFFER_SIZE];

    // Parse the input arguments
    if (sscanf(args, "%200s %d %[^\n]", filename, &data_len, data) != 3 || strlen(filename) > MAX_FILENAME_LEN || data_len > BUFFER_SIZE) {
        send_to_buffer(write_buf, "Error: Invalid arguments", 25);
        return;
    }

    directory_entry *entry = get_directory_entry(filename);
    if (entry == NULL) {
        send_to_buffer(write_buf, "File not found", 15);
        return;
    }

    inode *node = get_inode(entry->inode_index);
    if (!node || node->type != FILE_TYPE) {
        send_to_buffer(write_buf, "Not a file", 10);
        free(entry);
        return;
    }

    // Calculate the number of blocks needed
    int num_blocks_needed = (data_len + SECTOR_SIZE - 1) / SECTOR_SIZE;

    // If the new data is longer than the old data, allocate additional blocks if needed
    for (int i = 0; i < num_blocks_needed; i++) {
        if (node->direct_blocks[i] == -1) {
            int block_number = allocate_block();
            if (block_number == -1) {
                send_to_buffer(write_buf, "No free blocks available", 25);
                free(entry);
                return;
            }
            node->direct_blocks[i] = block_number;
        }
    }

    // // Write the new data to the file's blocks
    // for (int i = 0; i < num_blocks_needed; i++) {
    //     int block_number = node->direct_blocks[i];
    //     int bytes_to_write = (data_len > SECTOR_SIZE) ? SECTOR_SIZE : data_len;
    //     write_data_to_disk(data + (i * SECTOR_SIZE), block_number, nsec);
    //     data_len -= bytes_to_write;
    // }
    // Write the new data to the file's blocks
    data_len=data_len+1;

    for (int i = 0; i < num_blocks_needed; i++) {
        int block_number = node->direct_blocks[i];
        
        int bytes_to_write = (data_len > SECTOR_SIZE) ? SECTOR_SIZE : data_len;
        char block_data[SECTOR_SIZE+1] = {'\0'};
        strncpy(block_data, data + (i * SECTOR_SIZE), bytes_to_write);
        write_data_to_disk(block_data, block_number, nsec);
        data_len -= bytes_to_write;
    }

    // If the new data is shorter than the old data, free the unneeded blocks
    for (int i = num_blocks_needed; i < NUM_DIRECT_POINTERS; i++) {
        if (node->direct_blocks[i] != -1) {
            free_blocks[node->direct_blocks[i]] = 1;
            node->direct_blocks[i] = -1;
        }
    }

    // Update the inode size and modification time
    int pre_size = node->size;
    node->size = num_blocks_needed * SECTOR_SIZE;
    node->last_modified = time(NULL);
    write_inode_to_disk(node, entry->inode_index);
    update_file_size(current_directory_inode, node->size - pre_size);
    send_to_buffer(write_buf, "file written", 13);
    free(entry);
    return;
}
void cat(tcp_buffer *write_buf, char *args, int len) {
    char filename[MAX_FILENAME_LEN + 1];
    if (sscanf(args, "%200s", filename) != 1 || strlen(filename) > MAX_FILENAME_LEN) {
        send_to_buffer(write_buf, "Error: Invalid arguments", 25);
        return;
    }

    directory_entry *entry = get_directory_entry(filename);
    if (entry == NULL) {
        send_to_buffer(write_buf, "File not found", 15);
        return;
    }

    inode *node = get_inode(entry->inode_index);
    if (!node || node->type != FILE_TYPE) {
        send_to_buffer(write_buf, "Not a file", 10);
        free(entry);
        return;
    }

    char buffer[BUFFER_SIZE];
    char result[BUFFER_SIZE]="";  // 预分配足够的空间以存储所有块的数据
    int total_bytes_read = 0;

    for (int i = 0; i < NUM_DIRECT_POINTERS && node->direct_blocks[i] != -1; i++) {
        read_block(node->direct_blocks[i], buffer, sizeof(buffer));
        printf("buffer: %s\n",buffer);
        strncat(result, buffer, SECTOR_SIZE);
        printf("result: %s\n",result);
        total_bytes_read += strlen(buffer);
    }

    if (total_bytes_read == 0) {
        send_to_buffer(write_buf, "File is empty", 14);
    } else {
        send_to_buffer(write_buf, result, strlen(result) + 1);
    }

    free(entry);
}
void insert_into_file(tcp_buffer *write_buf, char *args, int len) {
    char filename[MAX_FILENAME_LEN + 1];
    int position, data_len;
    char data[BUFFER_SIZE];

    // Parse the input arguments
    if (sscanf(args, "%200s %d %d %[^\n]", filename, &position, &data_len, data) != 4 || strlen(filename) > MAX_FILENAME_LEN || data_len > BUFFER_SIZE) {
        send_to_buffer(write_buf, "Error: Invalid arguments", 25);
        return;
    }

    directory_entry *entry = get_directory_entry(filename);
    if (entry == NULL) {
        send_to_buffer(write_buf, "File not found", 15);
        return;
    }

    inode *node = get_inode(entry->inode_index);
    if (!node || node->type != FILE_TYPE) {
        send_to_buffer(write_buf, "Not a file", 10);
        free(entry);
        return;
    }

    // Read the existing file content
    char current_content[BUFFER_SIZE] = "";
    char buffer[BUFFER_SIZE];
    int total_bytes_read = 0;
    for (int i = 0; i < NUM_DIRECT_POINTERS && node->direct_blocks[i] != -1; i++) {
        read_block(node->direct_blocks[i], buffer, sizeof(buffer));
        strncat(current_content, buffer, SECTOR_SIZE);
        total_bytes_read += strlen(buffer);
    }

    // Ensure position is within the current content length
    if (position > total_bytes_read) {
        position = total_bytes_read;
    }

    // Insert the new data at the specified position
    char new_content[BUFFER_SIZE];
    snprintf(new_content, sizeof(new_content), "%.*s%s%s", position, current_content, data, current_content + position);

    // Calculate the number of blocks needed for the new content
    int new_content_len = strlen(new_content);
    int num_blocks_needed = (new_content_len + SECTOR_SIZE - 1) / SECTOR_SIZE;

    // Write the new content to the file's blocks
    for (int i = 0; i < num_blocks_needed; i++) {
        if (node->direct_blocks[i] == -1) {
            int block_number = allocate_block();
            if (block_number == -1) {
                send_to_buffer(write_buf, "No free blocks available", 25);
                free(entry);
                return;
            }
            node->direct_blocks[i] = block_number;
        }
        int block_number = node->direct_blocks[i];
        int bytes_to_write = (new_content_len > SECTOR_SIZE) ? SECTOR_SIZE : new_content_len;
        char block_data[SECTOR_SIZE+1] = {'\0'};
        strncpy(block_data, new_content + (i * SECTOR_SIZE), bytes_to_write);
        write_data_to_disk(block_data, block_number, nsec);
        new_content_len -= bytes_to_write;
    }

    // Free any unused blocks if the new content is shorter than the old content
    for (int i = num_blocks_needed; i < NUM_DIRECT_POINTERS; i++) {
        if (node->direct_blocks[i] != -1) {
            free_blocks[node->direct_blocks[i]] = 1;
            node->direct_blocks[i] = -1;
        }
    }

    // Update the inode size and modification time
    int pre_size = node->size;
    node->size = strlen(new_content);
    node->last_modified = time(NULL);
    write_inode_to_disk(node, entry->inode_index);
    update_file_size(current_directory_inode, node->size - pre_size);
    send_to_buffer(write_buf, "file updated", 13);
    free(entry);
}
void delete_from_file(tcp_buffer *write_buf, char *args, int len) {
    char filename[MAX_FILENAME_LEN + 1];
    int position, delete_len;

    // Parse the input arguments
    if (sscanf(args, "%200s %d %d", filename, &position, &delete_len) != 3 || strlen(filename) > MAX_FILENAME_LEN) {
        send_to_buffer(write_buf, "Error: Invalid arguments", 25);
        return;
    }

    directory_entry *entry = get_directory_entry(filename);
    if (entry == NULL) {
        send_to_buffer(write_buf, "File not found", 15);
        return;
    }

    inode *node = get_inode(entry->inode_index);
    if (!node || node->type != FILE_TYPE) {
        send_to_buffer(write_buf, "Not a file", 10);
        free(entry);
        return;
    }

    // Read the existing file content
    char current_content[BUFFER_SIZE] = "";
    char buffer[BUFFER_SIZE];
    int total_bytes_read = 0;
    for (int i = 0; i < NUM_DIRECT_POINTERS && node->direct_blocks[i] != -1; i++) {
        read_block(node->direct_blocks[i], buffer, sizeof(buffer));
        strncat(current_content, buffer, SECTOR_SIZE);
        total_bytes_read += strlen(buffer);
    }

    // Ensure position is within the current content length
    if (position > total_bytes_read) {
        position = total_bytes_read;
    }

    // Calculate the actual length to delete
    int actual_delete_len = (position + delete_len > total_bytes_read) ? total_bytes_read - position : delete_len;

    // Create the new content by deleting the specified data
    char new_content[BUFFER_SIZE];
    snprintf(new_content, sizeof(new_content), "%.*s%s", position, current_content, current_content + position + actual_delete_len);

    // Calculate the number of blocks needed for the new content
    int new_content_len = strlen(new_content);
    int num_blocks_needed = (new_content_len + SECTOR_SIZE - 1) / SECTOR_SIZE;

    // Write the new content to the file's blocks
    for (int i = 0; i < num_blocks_needed; i++) {
        if (node->direct_blocks[i] == -1) {
            int block_number = allocate_block();
            if (block_number == -1) {
                send_to_buffer(write_buf, "No free blocks available", 25);
                free(entry);
                return;
            }
            node->direct_blocks[i] = block_number;
        }
        int block_number = node->direct_blocks[i];
        int bytes_to_write = (new_content_len > SECTOR_SIZE) ? SECTOR_SIZE : new_content_len;
        char block_data[SECTOR_SIZE+1] = {'\0'};
        strncpy(block_data, new_content + (i * SECTOR_SIZE), bytes_to_write);
        write_data_to_disk(block_data, block_number, nsec);
        new_content_len -= bytes_to_write;
    }

    // Free any unused blocks if the new content is shorter than the old content
    for (int i = num_blocks_needed; i < NUM_DIRECT_POINTERS; i++) {
        if (node->direct_blocks[i] != -1) {
            free_blocks[node->direct_blocks[i]] = 1;
            node->direct_blocks[i] = -1;
        }
    }

    // Update the inode size and modification time
    int pre_size = node->size;
    node->size = strlen(new_content);
    node->last_modified = time(NULL);
    write_inode_to_disk(node, entry->inode_index);
    update_file_size(current_directory_inode, node->size - pre_size);
    send_to_buffer(write_buf, "file updated", 13);
    free(entry);
}
// void write_free_blocks_to_disk() {
//     char buffer[BUFFER_SIZE];
//     for (int i = 0; i < FREE_BLOCKS_SIZE; i++) {
//         memcpy(buffer, free_blocks + i * SECTOR_SIZE / sizeof(int), SECTOR_SIZE);
//         write_data_to_disk(buffer, FREE_BLOCKS_START + i, nsec);
//     }
// }
void write_free_blocks_to_disk() {
    char buffer[BUFFER_SIZE];
    int total_blocks = FREE_BLOCKS_SIZE;
    int remaining_bytes = sizeof(int) * ncyl * nsec;
    for (int i = 0; i < total_blocks; i++) {
        int bytes_to_copy = (remaining_bytes < SECTOR_SIZE) ? remaining_bytes : SECTOR_SIZE;
        memcpy(buffer, free_blocks + i * SECTOR_SIZE / sizeof(int), bytes_to_copy);
        write_data_to_disk(buffer, FREE_BLOCKS_START + i, nsec);
        remaining_bytes -= SECTOR_SIZE;
    }
}
void write_inodes_to_disk() {
    char buffer[BUFFER_SIZE];
    for (int i = 0; i < MAX_INODES; i++) {
        if (inodes[i].is_used) {
            inode_to_string(&inodes[i], buffer, sizeof(buffer));
            int block_number = ncyl * nsec - 1 - i;
            write_data_to_disk(buffer, block_number, nsec);
        }
    }
}
void add_user(tcp_buffer *write_buf, char *args, int len) {
    char username[MAX_FILENAME_LEN + 1];
    char password[MAX_PASSWORD_LEN + 1];
    if (sscanf(args, "%200s %50s", username, password) != 2) {
        send_to_buffer(write_buf, "Error: Invalid arguments", 25);
        return;
    }
    int user_id = allocate_user();
    if (user_id == -1) {
        send_to_buffer(write_buf, "Error: No free user slots", 25);
        return;
    }
    strncpy(users[user_id].username, username, MAX_FILENAME_LEN);
    strncpy(users[user_id].password, password, MAX_PASSWORD_LEN);
    mkdir(write_buf, username, strlen(username));
//     int home_inode = allocate_inode();
//     if (home_inode == -1) {
//         users[user_id].is_used = 0;
//         send_to_buffer(write_buf, "Error: No free inodes", 21);
//         return;
//     }
//     inodes[home_inode].type = DIR_TYPE;
//     inodes[home_inode].parent_inode = 0; // Root is the parent
//     inodes[home_inode].last_modified = time(NULL);
//     inodes[home_inode].size = 0;
//     inodes[home_inode].owner_id = user_id;
//     inodes[home_inode].permissions = 1; // Public
//     users[user_id].home_inode = home_inode;
//     write_inode_to_disk(&inodes[home_inode], home_inode);
    
//     send_to_buffer(write_buf, "User added successfully", 24);
}
void logout(tcp_buffer *write_buf, char *args, int len) {
    if (current_user_id == -1) {
        send_to_buffer(write_buf, "No user is logged in", 21);
        return;
    }
    current_user_id = -1;
    //current_directory_inode = 0;
    //strcpy(current_path, "/");
    send_to_buffer(write_buf, "Logout successful", 18);
}
void login(tcp_buffer *write_buf, char *args, int len) {
    char username[MAX_FILENAME_LEN + 1];
    char password[MAX_PASSWORD_LEN + 1];
    if (sscanf(args, "%200s %50s", username, password) != 2) {
        send_to_buffer(write_buf, "Error: Invalid arguments", 25);
        return;
    }
    int user_id = authenticate_user(username, password);
    if (user_id == -1) {
        send_to_buffer(write_buf, "Error: Authentication failed", 29);
        return;
    }
    //cd(write_buf, username, strlen(username));
    current_user_id = user_id;
    // current_directory_inode = users[user_id].home_inode;
    // update_current_path(username);
    // //snprintf(current_path, sizeof(current_path), "/home/%s", username);
    send_to_buffer(write_buf, "Login successful", 17);
}
void delete_user(tcp_buffer *write_buf, char *args, int len) {
    char username[MAX_FILENAME_LEN + 1];
    if (sscanf(args, "%200s", username) != 1) {
        send_to_buffer(write_buf, "Error: Invalid arguments", 25);
        return;
    }
    for (int i = 0; i < MAX_USERS; i++) {
        if (users[i].is_used && strcmp(users[i].username, username) == 0) {
            users[i].is_used = 0;
            cmdrmdir(write_buf, username, strlen(username));
            
            //send_to_buffer(write_buf, "User deleted successfully", 26);
            return;
        }
    }
    send_to_buffer(write_buf, "Error: User not found", 21);
}

void chmod(tcp_buffer *write_buf, char *args, int len) {
    char filename[MAX_FILENAME_LEN + 1];
    int new_permissions;

    if (sscanf(args, "%200s %d", filename, &new_permissions) != 2 || strlen(filename) > MAX_FILENAME_LEN || (new_permissions != 0 && new_permissions != 1)) {
        send_to_buffer(write_buf, "Error: Invalid arguments", 25);
        return;
    }

    directory_entry *entry = get_directory_entry(filename);
    if (entry == NULL) {
        send_to_buffer(write_buf, "File or directory not found", 28);
        return;
    }

    inode *node = get_inode(entry->inode_index);
    if (!node) {
        send_to_buffer(write_buf, "Error retrieving inode", 23);
        free(entry);
        return;
    }

    // Check if the current user is the owner of the file or directory
    if (node->owner_id != current_user_id) {
        send_to_buffer(write_buf, "Permission denied", 18);
        free(entry);
        return;
    }

    // Change the permissions
    node->permissions = new_permissions;
    node->last_modified = time(NULL);
    write_inode_to_disk(node, entry->inode_index);

    send_to_buffer(write_buf, "Permissions updated", 20);
    free(entry);
}

int cmd_e(tcp_buffer *write_buf, char *args, int len) {
    send_to_buffer(write_buf, "Bye!", 5);
    write_free_blocks_to_disk();
    write_inodes_to_disk();
    write_users_to_disk();
    return -1;
}
static struct {
    const char *name;
    int (*handler)(tcp_buffer *write_buf, char *, int);
} cmd_table[] = {
    {"f", format_file_system},
    {"mk", mk},
    {"mkdir", mkdir},
    {"ls", ls},
    {"rm", rm},   // Add the rm command to the command table
    {"cd", cd},
    {"rmdir", cmdrmdir},
    {"w", write_to_file},
    {"cat", cat},
    {"i", insert_into_file},
    {"d", delete_from_file},
    {"login", login},
    {"logout", logout},
    {"adduser", add_user},
    {"deluser", delete_user},
    {"chmod", chmod},
    {"e", cmd_e},
};
#define NCMD (sizeof(cmd_table) / sizeof(cmd_table[0]))
int handle_client(int id, tcp_buffer *write_buf, char *msg, int len) {
    char *p = strtok(msg, " \r\n");
    int ret = 1;
    for (int i = 0; i < NCMD; i++)
        if (strcmp(p, cmd_table[i].name) == 0) {
            ret = cmd_table[i].handler(write_buf, p + strlen(p) + 1, len - strlen(p) - 1);
            break;
        }
    if (ret == 1) {
        static char unk[] = "Unknown command";
        send_to_buffer(write_buf, unk, sizeof(unk));
    }
    if (ret < 0) {
        return -1;
    }
}
void add_client(int id) {
    // some code that are executed when a new client is connected
    // you don't need this in step1
}
void clear_client(int id) {
    // some code that are executed when a client is disconnected
    // you don't need this in step2
}
void load_inodes_from_disk() {
    char data[BUFFER_SIZE];
    for (int i = 0; i < MAX_INODES; i++) {
        int block_number = ncyl * nsec - 1 - i;
        read_block(block_number, data, sizeof(data));
        if (strlen(data) > 0) {
            string_to_inode(data, &inodes[i]);
        }
    }
}
void read_free_blocks_from_disk() {
    char buffer[BUFFER_SIZE];
    int total_blocks = FREE_BLOCKS_SIZE;
    int remaining_bytes = sizeof(int) * ncyl*nsec;
    for (int i = 0; i < total_blocks; i++) {
        printf("1\n");
        read_block(FREE_BLOCKS_START + i, buffer, sizeof(buffer));
        printf("2\n");
        int bytes_to_copy = (remaining_bytes < SECTOR_SIZE) ? remaining_bytes : SECTOR_SIZE;
        printf("3\n");
        memcpy(free_blocks + i * SECTOR_SIZE / sizeof(int), buffer, bytes_to_copy);
        printf("4\n");
        remaining_bytes -= SECTOR_SIZE;
    }
}


int main(int argc, char *argv[]) {
    int port_bd = atoi(argv[1]);
    int port_fs = atoi(argv[2]);
    client = client_init("localhost", port_bd);
    static char buf[BUFFER_SIZE];
    strcpy(buf, "I");
    client_send(client, buf, strlen(buf) + 1);
    int n = client_recv(client, buf, sizeof(buf));
    buf[n] = 0;
    printf("%s\n", buf);
    sscanf(buf, "%d %d", &ncyl, &nsec);
    size = ncyl * nsec;
    FREE_BLOCKS_SIZE= (sizeof(int) * ncyl * nsec / SECTOR_SIZE + 1);
    printf("free_blocks_size: %d\n",FREE_BLOCKS_SIZE);
    free_blocks = (int *)malloc(size * sizeof(int));
    if (free_blocks == NULL) {
        // 检查内存分配是否成功
        fprintf(stderr, "Memory allocation failed\n");
        return 1;
    }
    load_inodes_from_disk();
    read_free_blocks_from_disk();  // Load free blocks state from disk
    read_users_from_disk();  // Load users from disk
    tcp_server server = server_init(port_fs, 1, add_client, handle_client, clear_client);
    server_loop(server);
}
